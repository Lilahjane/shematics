export interface Ingredient {
    quantity: number;
    unit: string;
    ingredient: string;
}
